import argparse
from obj import Dungeon, Challenger


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('-qn', '--question_num', type=int, default=1, help="Answer which question?")
    parser.add_argument('--level', type=str, default=1, help="Enter the level you want")
    parser.add_argument('-cn','--challenger_num', type=int, default=10, help='Number of challengers')
    parser.add_argument('--hp', type=int, default=5, help='Challenger heath points (default: 5)')
    parser.add_argument('--alpha', type=float, default=0, metavar='[0-1]', help='Alpha increase the probability of selected node')    
    opt = parser.parse_args()
    
    map_file_path = f"dungeons\\dungeon_{opt.level}.txt"
    
    dungeon = Dungeon(map_file_path)

    if opt.question_num == 1:
        print(dungeon)

    elif opt.question_num == 2:
        count_win = 0

        for _ in range(opt.challenger_num):
            challenger = Challenger(hp=opt.hp, dungeon=dungeon)
            challenger.random_walk()

            if challenger.win:
                count_win += 1
            
        print(f'{count_win/opt.challenger_num*100}% challenger took down the level {opt.level} dungeon.')

    elif opt.question_num == 3:
        count_win = 0

        for _ in range(opt.challenger_num):
            challenger = Challenger(hp=opt.hp, dungeon=dungeon)
            challenger.weighted_random_walk(opt.alpha)
            
            if challenger.win:
                count_win += 1
            
        print(f'{count_win/opt.challenger_num*100}% challenger took down the level {opt.level} dungeon.')
