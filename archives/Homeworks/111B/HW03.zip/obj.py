class Node:
    def __init__(self, name, content = None):
        self.name = name
        self.content = content

    def __str__(self):
        return f"Node name: {self.name}\nNode content: {self.content}"

class Edge:
    def __init__(self, src, dest):
        self.src = src
        self.dest = dest
    
    def getSource(self):
        return self.src
    
    def getDestination(self):
        return self.dest
    
    def __str__(self):
        result = f"Source node: {self.src.name}({self.src.name})\n"
        result += f"Destination node: {self.dest.name}({self.dest.name})"
        return result

class Dungeon:
    def __init__(self, map_file_path):
        self.nodes = []
        self.edges = {}

        
class Challenger:
    def __init__(self, hp, dungeon):
        # you can add additional input parameters if you need to
        self.hp = hp
        self.dungeon = dungeon
        self.win = False
        
    def random_walk(self):
        # If you arrive treasure node with key before your hp goes to 0, set self.win True
        
    def weighted_random_walk(self, alpha):
        # If you arrive treasure node with key before your hp goes to 0, set self.win True
            